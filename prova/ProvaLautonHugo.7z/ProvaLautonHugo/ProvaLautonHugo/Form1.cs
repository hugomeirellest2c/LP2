﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace ProvaLautonHugo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void lstBoxEstoque_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            lstBoxEstoque.Items.Clear();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] produtos = new double[14, 4];
            double totalGeral = 0;
            
            //RA: 0030482413004

            for (int i = 0; i < 14; i++)
            {
                lstBoxEstoque.Items.Add("------------------------------------------------------------------------");
                double totalMes = 0;
                for (int j = 0; j < 4; j++)
                {
                    string value = Interaction.InputBox($"Insira a entrada do Produto {i + 1} da Semana {j + 1}", "Entrada de dados");
                    int num;

                    if (string.IsNullOrWhiteSpace(value))
                    {
                        MessageBox.Show("Insira um valor que não seja nulo.");
                        j--;
                    }
                    else if (!int.TryParse(value, out num))
                    {
                        MessageBox.Show("Insira um valor inteiro válido.");
                        j--;
                    }
                    else if (num < 0)
                    {
                        MessageBox.Show("Insira um valor maior que 0.");
                        j--;
                    }
                    else 
                    {
                        produtos[i,j] = num;
                        totalMes += num;
                        lstBoxEstoque.Items.Add($"Total Entradas do Produto {i + 1} da Semana {j + 1}: {produtos[i,j]}");
                    }
                }

                lstBoxEstoque.Items.Add($">> Total Entradas do Produto {i + 1}: {totalMes}");
                totalGeral += totalMes;
            }

            lstBoxEstoque.Items.Add("------------------------------------------------------------------------");
            lstBoxEstoque.Items.Add($">> Total Geral Entradas: {totalGeral}");
        }
    }
}
